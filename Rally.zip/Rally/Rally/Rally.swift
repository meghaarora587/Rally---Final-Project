//
//  Rally.swift
//  Rally
//
//  Created by MacStudent on 2019-10-18.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import Foundation

class Rally {
    
    
    func check(vehicleItem : Vehicle) -> Bool {
        return false
    }
    
    func vehicleCount() -> Int {
        return 0
    }
    
}
