
//  main.swift
//  Rally
//
//  Created by MacStudent on 2019-10-18.
//  Copyright © 2019 MacStudent. All rights reserved.
//
import Foundation

// we are creating an object of class GrandPrix
var grandPrix = GrandPrix()
var category = ""
var vType = 1
var addMore = true
var isSide = true

while(addMore){
    
    //    vehicleMaxSpeed = 0.0
    //    var vehicleWeight = 0
    //    var vehicleFuel = 0
    //    var vehicleType = 0
    
    let vehicle = Vehicle()
    var isValid = true
    
    print("Enter the Name : ")
    let name = readLine()!
    
    print("Enter the Speed : ")
    let speed = Double(readLine()!)
    
    print("Enter the Weight : ")
    let weight = Int(readLine()!)
    
    print("Enter the Fuel : ")
    let fuel = Int(readLine()!)
    while(isValid){
        print("Select your Vehicle category : \n1 Car \n2 Motorbike")
        let type = readLine()!
        
        switch type{
        case "1":
            isValid = false
            vType = 1
            var select = true
            while(select){
                print("Select the type of car :  \n1 Touring car \n2 Racing car")
                let ct = readLine()!
                if(ct == "1"){
                    select = false
                    category = "Touring Car"
                    
                }else if(ct == "2"){
                    select = false
                    category = "Racing Car"
                }else{
                    print("\n Invalid Choice !!!   TRY AGAIN \n")
                    select = true
                }
                
            }
            
        case "2":
            isValid = false
            vType = 2
       
            var nxtvh = true
            while(nxtvh){
                
                print("Do you want motorcycle with sidecar ? \n1 Yes \n2 No")
                let side = readLine()!
                
                if(side == "1"){
                    nxtvh = false
                    isSide = true
                }else if(side == "2"){
                    nxtvh = false
                    isSide = false
                }else{
                    nxtvh = true
                    print("\n Invalid Choice !!!   TRY AGAIN\n")
                }
            }
        default:
            print("\n Invalid Choice !!!   TRY AGAIN\n")
            isValid = true
            break
        }
    }
    
  
    
    
    
    
    
    if(vType == 1){
        
        let car = Car(vehicleName: name, vehicleMaxSpeed: speed ?? 0.0, vehicleWeight: weight ?? 0, vehicleFuel: fuel ?? 0, categoryType: category, vehicleType: 1)
        
        grandPrix.add(vehicleItem: car)
        
    }else{
        
        let motorcycle = Motorcycle(vehicleName: name, vehicleMaxSpeed: speed ?? 0.0 , vehicleWeight: weight ?? 0, vehicleFuel: fuel ?? 0, isSidecar: isSide, vehicleType: 2)
        
        grandPrix.add(vehicleItem: motorcycle)
    }
    
    
    print("Do you want to add more vehicle ?  \n1 Yes \n2 No  ")
    
    let userchoice = readLine()!
    
    switch userchoice{
    case "1":
        addMore = true
    case "2":
        addMore = false
    default:
        addMore = false
        break
    }
    
    
    
}


// function for userinput to choose  number of vehicle for race
var totalVehicle:Int = grandPrix.vehicleCount()

var roundCount = 1
repeat{
    
repeat{
    
    print("Number of vehicles participated : \(totalVehicle) \nEnter number of vehicles for random race :")
    let ch:Int! = Int(readLine()!)
    
    if(ch > 0 && ch <= totalVehicle){

        
        // add  random vehcile those are left for race
        var Randomveh = ""
        if(roundCount == 1){
            Randomveh = "First"
        }else if(roundCount == 2){
                 Randomveh = "Second"
        }else if(roundCount == 3){
                 Randomveh = "Third"
        }
        
        grandPrix.run(turn: 100, selected: ch , roundName : Randomveh)
        roundCount += 1
        
        
        break;
        
    }else{
        print("Number of vehicles entered to race must be more than 0 and less than or equal to number of vehicles recorded. \n Try Again   ^_^ ")
    }
    
}while(true)

}while(roundCount < 4)

